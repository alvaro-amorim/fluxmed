"""Infrastructure adapters for FluxMed."""
